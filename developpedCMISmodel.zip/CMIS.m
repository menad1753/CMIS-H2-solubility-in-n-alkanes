clear
clc

load MLPmodel
load CFNNmodel
experimentalSol=0.095;
%inp=[Tc;Pc;w;T;P]
inp=[190.564;4.5992;0.01141;116.4833333;10.27316979];
SolMLP=netMLP(inp);
SolCFNN=netCFNN(inp);

SolCMIS=5.93262712993542*(10^(-5))-((0.00763934637053639*(SolCFNN*(2*SolCFNN-SolMLP*(SolCFNN-3*SolMLP+86))-47*SolMLP*(SolMLP+((SolCFNN-SolCFNN)^2)*(SolMLP+51))))/SolMLP)